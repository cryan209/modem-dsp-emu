/*****************************************************************************
 Copyright (c) 1999-2000, Intel Corporation 

 All rights reserved.

 Redistribution and use in source and binary forms, with or without 
 modification, are permitted provided that the following conditions are met:

 1. Redistributions of source code must retain the above copyright notice, 
 this list of conditions and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation 
 and/or other materials provided with the distribution.

 3. Neither the name of Intel Corporation nor the names of its contributors 
 may be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 

****************************************************************************/

#include "hamcore.h"
#include <linux/delay.h>
#include <linux/sched.h>
#include <linux/proc_fs.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <asm/system.h>
#include <asm/irq.h>
#include "uart.h"
#include "rts.h"

int hamcore_init(void*);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0) 
EXPORT_SYMBOL_NOVERS(UART_dte_from_char);
EXPORT_SYMBOL_NOVERS(UART_dce_flush);
EXPORT_SYMBOL_NOVERS(UART_dce_to_free);
EXPORT_SYMBOL_NOVERS(dspdrv_CommRamISR);
EXPORT_SYMBOL_NOVERS(line_int);
EXPORT_SYMBOL_NOVERS(dspdrv_clear_dsp_interrupt);
EXPORT_SYMBOL_NOVERS(UART_dce_to_num);
EXPORT_SYMBOL_NOVERS(UART_init);
EXPORT_SYMBOL_NOVERS(UART_dtr_off);
EXPORT_SYMBOL_NOVERS(hamcore_init);
EXPORT_SYMBOL_NOVERS(clm_initialize);
EXPORT_SYMBOL_NOVERS(get_register);
EXPORT_SYMBOL_NOVERS(UART_line_status);
EXPORT_SYMBOL_NOVERS(UART_dce_to_char);
EXPORT_SYMBOL_NOVERS(UART_rts_on);
EXPORT_SYMBOL_NOVERS(UART_dte_to_num);
EXPORT_SYMBOL_NOVERS(UART_dtr_on);
EXPORT_SYMBOL_NOVERS(UART_rts_off);
EXPORT_SYMBOL_NOVERS(ResetDspInternal);
EXPORT_SYMBOL_NOVERS(dspdrv_SetCramISRCallBack);
EXPORT_SYMBOL_NOVERS(clm_terminate);
EXPORT_SYMBOL_NOVERS(clm_configure);
EXPORT_SYMBOL_NOVERS(UART_msr_wait);

#if defined(TARGET_CATAWBA)
   EXPORT_SYMBOL_NOVERS(ModemCardStart);
   EXPORT_SYMBOL_NOVERS(ModemCardStop);
   EXPORT_SYMBOL_NOVERS(AfeIRQ);
#endif //catawba

#if defined(TARGET_SELAH)
   EXPORT_SYMBOL_NOVERS(IM_Peek_Reg);
#endif //selah

#endif //2.4.0

//globals
unsigned int*      dsp_irq;
unsigned int*      io_base;
unsigned int*      io_range;
unsigned int*      mm_range;

#if defined(TARGET_SELAH)
  extern PUCHAR       pBaseAddress;
#else
  extern PUCHAR       pMappedComram;
#endif

void (* rs_receive)(void);
void (* rs_sched_event)(void);
int (* Debug_Printf)(const char*, ...);
void (* kschedule)(void);
void   kdelay(short);
void kdisable_irq(unsigned int);
void kenable_irq(unsigned int);
#ifdef KGDB
extern void do_schedule(void);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
   struct semaphore exec_reg_sem = MUTEX;
   struct wait_queue* persistWriteQ = NULL;
   struct wait_queue* persistReadQ = NULL;
   struct wait_queue* persistShutdownQ = NULL;
#else
   DECLARE_MUTEX(exec_reg_sem);
   DECLARE_WAIT_QUEUE_HEAD(persistWriteQ);
   DECLARE_WAIT_QUEUE_HEAD(persistReadQ);
   DECLARE_WAIT_QUEUE_HEAD(persistShutdownQ);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,10)
   MODULE_LICENSE("Proprietary");
#endif

int sound_enabled = 0;
MODULE_PARM(sound_enabled, "i");

extern void ham_proc_shutdown(void);

//extern int ham_proc_function(char*, char**, off_t, int, int);
//extern int ham_proc_recieve(struct file*, const char*, unsigned long, void*); 
//extern read_proc_t hamproc_read;
//extern write_proc_t hamproc_write;
struct proc_dir_entry* hamproc;
extern int persist_hamproc_write(const char*);
extern int persist_hamproc_read(char*);


int hamproc_write(struct file* file, 
                     const char *buffer,
                     unsigned long count,
                     void *data)
{
   return(persist_hamproc_write(buffer));
}
//used to send data to app reading the ham proc
int hamproc_read(char* page,
                  char** start,
                  off_t offset,
                  int len, int* eof, void* data)
{
   return(persist_hamproc_read(page));
}

int create_hamproc()
{
   hamproc = create_proc_entry("ham", S_IFREG | S_IRUGO, &proc_root);
   if(hamproc == NULL) return -ENOMEM;
   hamproc->read_proc = hamproc_read;
   hamproc->write_proc = hamproc_write;
   return 0;
}
void detach_hamproc()
{
   remove_proc_entry("ham", &proc_root);
}

int hamcore_init(void * data)
{
   struct hamcore_data_struct* driver = (struct hamcore_data_struct*)data;
   Debug_Printf = printk;
#ifdef KGDB
   kschedule = do_schedule;
#else
   kschedule = schedule;
#endif
   #if defined(DEBUG_LINUX)
   printk(KERN_DEBUG"hamcore_init\n");
   #endif
   if(data == NULL)
   {
      printk(KERN_ALERT"null structure passed to hamcore_init\n");
      return -1;
   }
   if(driver->version != HAMCORE_VERSION)
   {
      printk(KERN_ALERT"hamcore_init: structure version != %d\n",
             HAMCORE_VERSION);
      return -1;
   }

   if(driver->dsp_irq)
   {
      dsp_irq = driver->dsp_irq;
//      printk(KERN_DEBUG"hamcore_init:dsp_irq %x,%x,%x\n",
//            &dsp_irq, dsp_irq, *dsp_irq);
   }else
   {
      printk(KERN_ALERT"dsp_irq is null\n");
      return -1;
   }
   if(driver->io_base)
   {
      io_base = driver->io_base;
//      printk(KERN_DEBUG"hamcore_init:io_base %x,%x,%x\n",
//             &io_base,io_base, *io_base);
   }else
   {
      printk(KERN_ALERT"hamcore_init:io_base is null\n");
      return -1;
   }
   if(driver->io_range)
   {
      io_range = driver->io_range;
//      printk(KERN_DEBUG"hamcore_init:io_range addr=0x%X, val=%u\n",
//             io_range,*io_range);
   }else
   {
      printk(KERN_ALERT"hamcore_init:io_range is null\n");
      return -1;
   }
#if !defined(TARGET_CATAWBA)
   if(driver->mm_base)
   {
      #if defined(TARGET_SELAH)
        pBaseAddress = (PUCHAR) driver->mm_base;
      #else
      pMappedComram = driver->mm_base;
      #endif
   }
   else
   {
      printk(KERN_ALERT"hamcore_init:mm_base is null\n");
     return -1;
   }
   if(driver->mm_range)
   {
     mm_range = driver->mm_range;
   }
   else
   {
      printk(KERN_ALERT"hamcore_init:mm_range is null\n");
      return -1;
   }
#endif // NOT TARGET_CATAWBA
   if(driver->rs_receive)
   {
      rs_receive = driver->rs_receive;
//      printk(KERN_DEBUG"hamcore_init:rs_receive addr=0x%X\n",
//             rs_receive);
   }else
   {
      printk(KERN_ALERT"hamcore_init:rs_receive is null\n");
      return -1;
   }

   if(driver->rs_sched_event)
   {
      rs_sched_event = driver->rs_sched_event;
//      printk(KERN_DEBUG"hamcore_init:rs_sched_event addr=0x%X\n",
//             (unsigned int)rs_sched_event);
   }else
   {
      printk(KERN_ALERT"hamcore_init:rs_sched_event is null\n");
      return -1;
   }
   #if defined(DEBUG_LINUX)
   printk("hamcore_init:done\n");
   #endif
#if defined (TARGET_CATAWBA)
   modem_init(driver);
#endif // TARGET_CATAWBA
   return 0;
}
//************************************************************************
//Function name:  init_module
//Description:    if TARGET_CATAWBA we start AFE initialization; 
//				HAM registration 
//Inputs:         
//Outputs:        Status Err or Ok
//Notes:          Module initialization handler

int init_module(void)
{
   int rc;
   rc = create_hamproc();
   printk(KERN_INFO"hamcore module init\n");
   return rc;
}

//************************************************************************
//Function name:  cleanup_module
//Description:    
//Inputs:         
//Outputs:        
//Notes:          Module dainitialization handler
//*************************************************************************/
void cleanup_module(void)
{
   printk(KERN_INFO"hamcore module cleanup\n");
   ham_proc_shutdown();
   detach_hamproc();
   #if defined (TARGET_CATAWBA)
      modem_kill();
   #endif
}

void kdelay(short x)
{
//   printk(KERN_INFO"hamdelay %d\n",x);
   mdelay(x);
}
void kudelay(unsigned long x)
{
   udelay(x);
}

void kcli(void)
{
   cli();
}

void ksave_flags(unsigned long* flags)
{
   save_flags(*flags);
}

void krestore_flags(unsigned long flags)
{
   restore_flags(flags);
}


void up_exec_reg_sem(void)
{
   up(&exec_reg_sem);
}

void down_exec_reg_sem(void)
{
   down(&exec_reg_sem);
}

void wake_up_interruptible_persistWriteQ(void)
{
   wake_up_interruptible(&persistWriteQ);
}

void wake_up_interruptible_persistReadQ(void)
{
   wake_up_interruptible(&persistReadQ);
}


void interruptible_sleep_on_persistReadQ(void)
{
   interruptible_sleep_on(&persistReadQ);
}

void interruptible_sleep_on_timeout_persistWriteQ(int* pkt_from_app, unsigned long timeout)
{
   while((*pkt_from_app == FALSE) && timeout > 0) //while we have not gotten ack pkt yet.
   {
      timeout = interruptible_sleep_on_timeout(&persistWriteQ, timeout);
   }
}

void interruptible_sleep_on_timeout_persistReadQ(int* pkt_to_app, unsigned long timeout)
{
   while((*pkt_to_app == TRUE) && timeout > 0) //while pkt hasnt been read yet.
   {
      timeout = interruptible_sleep_on_timeout(&persistReadQ, timeout);
   }
}

void ham_proc_shutdown_wait()
{
   int timeout = HZ*2;
   while(timeout > 0)
   {
      current->state = TASK_INTERRUPTIBLE;
      timeout = schedule_timeout(timeout);
   }
}

void kdisable_irq(unsigned int irq)
{
#if defined (TARGET_CATAWBA)
#else
   disable_irq(irq);
#endif
}

void kenable_irq(unsigned int irq)
{
#if defined (TARGET_CATAWBA)
#else
   enable_irq(irq);
#endif

}

char* kCurrentComm()
{
   return(current->comm);
}

