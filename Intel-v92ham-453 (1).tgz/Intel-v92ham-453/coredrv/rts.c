/*****************************************************************************
 Copyright (c) 1999-2000, Intel Corporation 

 All rights reserved.

 Redistribution and use in source and binary forms, with or without 
 modification, are permitted provided that the following conditions are met:

 1. Redistributions of source code must retain the above copyright notice, 
 this list of conditions and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation 
 and/or other materials provided with the distribution.

 3. Neither the name of Intel Corporation nor the names of its contributors 
 may be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 

****************************************************************************/


#include "hamcore.h"
#include <linux/sched.h>
#include <linux/tqueue.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/version.h>
#include <asm/system.h>
#include <asm/irq.h>


#include "rts.h"

#define MAX_TASK_RUN_TIME   10

volatile ubyte rs_task_enabled = FALSE;
volatile ubyte rs_task_running = FALSE;
volatile ubyte rs_timer_running = FALSE;

volatile ubyte rs_task_yielded = FALSE;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
struct wait_queue *yield_wq = NULL;
struct wait_queue *terminate_wq = NULL;
#else
   DECLARE_WAIT_QUEUE_HEAD(yield_wq);
   DECLARE_WAIT_QUEUE_HEAD(terminate_wq);
#endif

volatile ulong rts_ticks;
volatile ulong rts_timeout;
volatile ulong rts_timer;
volatile ulong global_ham_timer;

struct timer_list rs_timer;

void RTS_Task(void *ptr);
struct tq_struct  rs_task =
{
   routine: (void (*) (void*)) RTS_Task,
   data: NULL
};

void RTS_Timer(unsigned long ptr);
void RTS_Task_Schedule(void);
void RTS_Task_Terminate(void);

extern void acu_timer(void);

/****************************************************************************
/ Function:  RTS_Enable
/
/ Remarks:   Enables Real-Time Services
/
/ Inputs;    none
/
/ Outputs:   none
*****************************************************************************/
void RTS_Enable(void)
{
   if (!rs_timer_running)
   {
      rs_timer_running = TRUE;
      rs_task_enabled = TRUE;

      rts_ticks = 0;
      rts_timeout = RTS_ASYNC_TIMER;
      rts_timer = rts_timeout;

      /* initialize RTS task */
      rs_task_running = FALSE;
      rs_task_yielded = FALSE;

      /* initialize RTS timer */
      init_timer(&rs_timer);

      /* schedule RTS timer to run */
      rs_timer.function = RTS_Timer;
      rs_timer.data = 0;
      rs_timer.expires = jiffies + 1;
      add_timer(&rs_timer);
   }
}

/****************************************************************************
/ Function:  RTS_Disable
/
/ Remarks:   Disables Real-Time Services
/
/ Inputs;    none
/
/ Outputs:   none
*****************************************************************************/
void RTS_Disable(void)
{
   if (rs_timer_running)
   {
      /* stop RTS timer */
      del_timer(&rs_timer);
      
      rs_timer_running = FALSE;
   }
}

/****************************************************************************
/ Function:  RTS_Get_Ticks
/
/ Remarks:   Gets RTS tick counter
/
/ Inputs;    none
/
/ Outputs:   ticks - current system tick counter
*****************************************************************************/
ulong RTS_Get_Ticks(void)
{
   return (rts_ticks);
}

/****************************************************************************
/ Function:  RTS_Set_Timeout
/
/ Remarks:   This routine allows the RTS timer frequency to be adjusted.
/
/ Inputs;    timeout - timeout frequency (in msec)
/
/ Outputs:   none
*****************************************************************************/
void RTS_Set_Timeout(ulong timeout)
{
   ulong flags;
   
   save_flags(flags);
   cli();

   rts_timeout = timeout;

   restore_flags(flags);
}

/****************************************************************************
/ Function:  RTS_Timer
/
/ Remarks:   RTS timer handler
/
/ Inputs;    none
/
/ Outputs:   none
*****************************************************************************/
extern void linux_sys_isr_timer_ticker(void);
#define NANO_TIME_QUANTUM 1000000000/HZ 
void RTS_Timer(unsigned long ptr)
{
    static unsigned long time = 0;
    static unsigned long past_jiffies = 0;

    if(past_jiffies==0) past_jiffies=jiffies-1;

    if (rs_timer_running)
    {
        time = time + (NANO_TIME_QUANTUM * (jiffies-past_jiffies));
        while(time >= 10000000)
        {
            time = time - 10000000;

            linux_sys_isr_timer_ticker(); 
            global_ham_timer--;
            rts_ticks += 10;
            acu_timer();
            if (rts_timer >= 10)
                rts_timer -= 10;
            else
            rts_timer = 0;

            if (rts_timer == 0)
            {
                RTS_Task_Schedule();
            }
        }
        past_jiffies = jiffies;
        /* reschedule RTS timer to run again */
        rs_timer.expires = jiffies + 1;
        add_timer(&rs_timer);
   }
}

/****************************************************************************
/ Function:  RTS_Task
/
/ Remarks:   RTS Task (bottom half)
/
/ Inputs;    ptr
/
/ Outputs:   none
*****************************************************************************/
void RTS_Task(void *ptr)
{
   int   i;
   for (i = 0; (i < 10) && rs_task_enabled && rs_task_running; i++)

   {
      clm_bg();
   }
   rs_task_running = FALSE;
   wake_up_interruptible(&terminate_wq);
}

/****************************************************************************
/ Function:  RTS_Task_Schedule
/
/ Remarks:   This routine schedules RTS_Task to run.  If RTS_Task is not
/            currently running, it will be scheduled to run.  If RTS_Task
/            is already running but has yielded, then it will be awakened.
/
/ Inputs;    none
/
/ Outputs:   none
*****************************************************************************/
void RTS_Task_Schedule(void)
{
   if (rs_task_enabled)
   {
      /* if RTS_Task() is not currently running, start it */
      if (!rs_task_running)
      {
         rts_timer = rts_timeout;
         rs_task_running = TRUE;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
         queue_task(&rs_task, &tq_scheduler);
#else
         schedule_task(&rs_task);
#endif
      }
      /* if RTS_Task() is running but is currently suspended, resume it */
      else if (rs_task_yielded)
      {
         rts_timer = rts_timeout;
         rs_task_yielded = FALSE;
         wake_up_interruptible(&yield_wq);
      }
   }
}

/****************************************************************************
/ Function:  RTS_Task_Terminate
/
/ Remarks:   This routine attempts to terminate RTS_Task gracefully.
/
/ Inputs;    none
/
/ Outputs:   none
*****************************************************************************/
void RTS_Task_Terminate(void)
{
   int timeout = HZ*4;
   /* don't allow task rescheduling until RTS_Enable() is called again */
   rs_task_enabled = FALSE;

   while(rs_task_running && timeout > 0)
   {
      #if defined(DEBUG_LINUX_TASK)
         printk(KERN_INFO"ham: task terminate T%d\n", timeout);
      #endif
      timeout = interruptible_sleep_on_timeout(&terminate_wq, timeout);
   }
   #if defined(DEBUG_LINUX_TASK)
      printk(KERN_INFO"ham task terminated, to=%d\n", timeout);
   #endif
}
/*
   // if RTS_Task is currently running, wait for it to stop 
   if (rs_task_running)
   {
      // give RTS_Task time to complete current time-slice 
      current->state = TASK_INTERRUPTIBLE;
      current->counter = 0;  // make us low-priority 
      schedule_timeout(10);
      current->state = TASK_RUNNING;

      // if RTS_Task is still running, terminate it by force
      if (rs_task_running)
      {
         rs_task_running = FALSE;

         current->state = TASK_INTERRUPTIBLE;
         current->counter = 0;  // make us low-priority 
         schedule_timeout(10);
         current->state = TASK_RUNNING;
      }
   }
*/

