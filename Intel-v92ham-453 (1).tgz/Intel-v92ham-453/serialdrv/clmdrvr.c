/*****************************************************************************
  The code from this file (clmdrvr.c) is based on the code from serial.c written 
  by Linus Torvalds.

  Copyright  1991, 1992  Linus Torvalds
  Copyright  1999-2002, Intel Corporation

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  Revisions:

  2001/11/04: Nikolaus Voss voss@informatik.uni-hamburg.de
              Reworked PCI-resource allocation to use kernel-system. Modem
              should now work with PNP-Sytems.

*****************************************************************************/

#include "hamcore.h"
#include <linux/module.h>
#include <linux/tty.h>
#include <linux/serial.h>
#include <linux/serialP.h>
#include <linux/serial_reg.h>
#include <linux/proc_fs.h>
#include <linux/version.h>
#include <linux/errno.h>
#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/major.h>
#include <linux/string.h>
#include <linux/fcntl.h>
#include <linux/ptrace.h>
#include <linux/ioport.h>
#include <linux/slab.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/pci.h>

#include <asm/system.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/bitops.h>
#include <asm/serial.h>

#include "uart.h"

int  init_module(void);

void cleanup_module(void);
int  rs_init(void);
//static int rs_init(void);
//static void cleanup_module(void);

static void rs_receive(void);
static void rs_sched_event(void);

static int  rs_open(struct tty_struct *tty, struct file *file_ptr);
static void rs_close(struct tty_struct *tty, struct file *file_ptr);
static void rs_start(struct tty_struct *tty);
static void rs_stop(struct tty_struct *tty);
static int  rs_write(struct tty_struct *tty, int from_user, const
   unsigned char *buf, int length);
static void rs_put_char(struct tty_struct *tty, unsigned char ch);
static void rs_flush_chars(struct tty_struct *tty);
static int  rs_write_room(struct tty_struct *tty);
static int  rs_chars_in_buffer(struct tty_struct *tty);
static void rs_flush_buffer(struct tty_struct *tty);
static int  rs_ioctl(struct tty_struct *tty, struct file *file_ptr,
   unsigned int cmd, unsigned long arg);
static void rs_throttle(struct tty_struct *tty);
static void rs_unthrottle(struct tty_struct *tty);
static void rs_send_xchar(struct tty_struct *tty, char ch);
static void rs_set_termios(struct tty_struct *tty, struct termios
   *old_termios);
static void rs_hangup(struct tty_struct *tty);
static void rs_break(struct tty_struct *tty, int break_state);
static void rs_wait_until_sent(struct tty_struct *tty, int timeout);
static int  get_modem_info(struct tty_struct *tty, unsigned int *value);
static int  set_modem_info(struct tty_struct *tty, unsigned int cmd,
   unsigned int *value);
static void rs_interrupt(int irq, void *dev_id, struct pt_regs *regs);

static void rs_event_handler(void *ptr);

//static int  rs_count = 0;
static struct async_struct rs_async[CLM_PORTS];

struct tty_driver serial_driver;
static int serial_refcount;

static struct tty_struct *serial_table[CLM_PORTS];
static struct termios *serial_termios[CLM_PORTS];
static struct termios *serial_termios_locked[CLM_PORTS];

static struct serial_state serial_states[] = { SERIAL_PORT_DFNS };

static unsigned char *tmp_buf;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
   static struct semaphore tmp_buf_sem = MUTEX;
#else
   static DECLARE_MUTEX(tmp_buf_sem);
#endif




static int gMajorNum = CLM_MAJOR;
static int gSHIRQ = 1;

MODULE_AUTHOR("Intel Corporation");
MODULE_DESCRIPTION("Intel Data Fax LinModem");
MODULE_PARM(gMajorNum, "i");
MODULE_PARM(gSHIRQ, "i");

#if defined (TARGET_CATAWBA)
   MODULE_SUPPORTED_DEVICE("Intel 537 Soft Modem");
#elif defined (TARGET_SELAH)
   MODULE_SUPPORTED_DEVICE("536ep Controllerless Modem");
#elif defined (TARGET_HAM)
   MODULE_SUPPORTED_DEVICE("MD563X-HaM (Host Accelerated Modem)");
#else
   #error no target defined
#endif
EXPORT_NO_SYMBOLS;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,10)
   MODULE_LICENSE("GPL");
#endif

unsigned int ham_io_base;
unsigned int ham_io_range;
unsigned int ham_mem_base;
unsigned int ham_mem_range;
void* ham_dsp_base;
unsigned int ham_dsp_irq;

extern void clm_configure(void);
extern int hamcore_init(void*);
struct hamcore_data_struct hamcore_data;

#if defined (TARGET_CATAWBA)
struct pci_dev *find_device(void *data)
{
	// We assume 1 or 0 catawba devices installed. This is stated in requirements.
    struct pci_dev *pdev = NULL;
    struct hamcore_data_struct* driver = (struct hamcore_data_struct*)data;

    // This should be first!!!
    pdev = pci_find_device (TJ320_VENDOR_ID, TJ320_DEVICE_ID, pdev);
    if (pdev)
    {
        driver->afe_type = TJ320_VENDOR_ID;
	    return pdev;
    }

    pdev = pci_find_device (SI3052_VENDOR_ID, SI3052_DEVICE_ID, pdev);
    if (pdev)
{
        driver->afe_type = SI3052_VENDOR_ID;
	    return pdev;
    }

    pdev = pci_find_device (ALI_VENDOR_ID, ALI_DEVICE_ID, pdev);
    if (pdev)
    {
        driver->afe_type = ALI_VENDOR_ID;
	    return pdev;
   }

    pdev = pci_find_device (INTEL_VENDOR_ID, INTEL_DEVICE_ID, pdev);
    if (pdev)
    {
        driver->afe_type = INTEL_VENDOR_ID;
	    return pdev;
}

    pdev = pci_find_device (NVIDIA_VENDOR_ID, NVIDIA_DEVICE_ID, pdev);
    if (pdev)
    {
        driver->afe_type = NVIDIA_VENDOR_ID;
	    return pdev;
    }

    pdev = pci_find_device (SIS_VENDOR_ID, SIS_DEVICE_ID, pdev);
    if (pdev)
    {
        driver->afe_type = SIS_VENDOR_ID;
	    return pdev;
    }

    pdev = pci_find_device (VIA_VENDOR_ID, VIA_DEVICE_ID, pdev);
    if (pdev)
{
        driver->afe_type = VIA_VENDOR_ID;
	    return pdev;
    }

   return 0;
}
#endif

/**************************************************************************
/ Function:  init_module
/
// Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
int init_module(void)
{
   int status = 0;

   if (pci_present())
   {
      struct pci_dev *pdev = NULL;
      struct pci_dev *pdev0 = NULL;

      memset(&hamcore_data, 0, sizeof(struct hamcore_data_struct));
#if defined (TARGET_CATAWBA)
      pdev = find_device (&hamcore_data);
#else
      pdev0 = pdev = pci_find_device (MDM_PCI_VENDOR_ID, MDM_PCI_DEVICE_ID, pdev);
#endif
      if (!pdev)
      {
	      printk(KERN_INFO "ham: device not found.\n");
	      return 1;
      }

#if defined(TARGET_HAMPLUS)
      pdev = pci_find_device (MDM_PCI_VENDOR_ID, MDM_PCI_DEVICE_ID, pdev);
      if (!pdev)
      {
	      printk(KERN_INFO "ham: device not found.\n");
	      return 1;
      }
#endif

      printk(KERN_NOTICE"ham: loading %s\n", VERSION_MSG);

      if (pci_enable_device(pdev))
      {
	      printk(KERN_INFO "ham: could not enable device.\n");
	      return 1;
      }

      ham_mem_base = pci_resource_start (pdev, 0);
      ham_mem_range = pci_resource_len (pdev, 0);
      ham_io_base = pci_resource_start (pdev, 1);
      ham_io_range = pci_resource_len (pdev, 1);

      ham_dsp_irq = pdev->irq;

      ham_dsp_base = ioremap(ham_mem_base, ham_mem_range);

      printk(KERN_INFO "ham: IRQ: %d, DSP-Base: 0x%x (phys) 0x%x (virt) "\
	     "(range: %dk), DSP-Port: 0x%x (range: %db)\n", 
	     ham_dsp_irq, ham_mem_base, (unsigned int)ham_dsp_base,
	     ham_mem_range/1024, ham_io_base, ham_io_range);

      hamcore_data.version = HAMCORE_VERSION;
      hamcore_data.dsp_irq = &ham_dsp_irq;
      hamcore_data.io_base = &ham_io_base;
      hamcore_data.io_range = &ham_io_range;
#if defined (TARGET_CATAWBA)
      hamcore_data.mm_base  = &ham_mem_base;
      hamcore_data.mm_range = &ham_mem_range;
      hamcore_data.sound_enabled = sound_enabled;
      hamcore_data.pdev = pdev;
#else
      hamcore_data.mm_base  = ham_dsp_base;     // CRam !
      hamcore_data.mm_range = &ham_mem_range;   // Cram !
#endif
      hamcore_data.rs_receive = rs_receive;
      hamcore_data.rs_sched_event = rs_sched_event;
      if(hamcore_init(&hamcore_data) != 0)
      {
         printk(KERN_ALERT"hamcore did not init\n");
         free_irq(ham_dsp_irq, &gSHIRQ);
         release_region(ham_io_base, ham_io_range);

         vfree(ham_dsp_base);
         return -1;
      }
      /* now perform driver initialization */
      status = rs_init();
   }
   else
   {
      printk(KERN_ERR"ham: Could not find HaM modem\n");
   }


   return (status);
}

/***************************************************************************
/ Function:  cleanup_module
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
void cleanup_module(void)
{
   printk(KERN_NOTICE"ham:unloading %s\n", VERSION_MSG);
   tty_unregister_driver(&serial_driver);
   /* free hardware resources */
   free_irq(ham_dsp_irq, &gSHIRQ);

   vfree(ham_dsp_base);

    printk(KERN_NOTICE"ham: unload done\n");
}

/***************************************************************************
/ Function:  rs_init
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
__initfunc(int rs_init(void))
#else
int rs_init(void)
#endif
{
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:init:uart\n");
   #endif
   UART_init();
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:init:serialdriver\n");
   #endif
   memset(&serial_driver, 0, sizeof(struct tty_driver));
   serial_driver.magic = TTY_DRIVER_MAGIC;
   serial_driver.driver_name = CLM_DRIVER_NAME;
   serial_driver.name = MDM_DEVICE_NAME;
   serial_driver.major = gMajorNum;
   serial_driver.minor_start = CLM_MINOR_START;
   serial_driver.num = CLM_PORTS;
   serial_driver.type = TTY_DRIVER_TYPE_SERIAL;
   serial_driver.subtype = SERIAL_TYPE_NORMAL;
   serial_driver.init_termios = tty_std_termios;
   serial_driver.init_termios.c_cflag = B38400 | CS8 | CREAD | HUPCL | CLOCAL;
   serial_driver.flags = TTY_DRIVER_REAL_RAW;
   serial_driver.refcount = &serial_refcount;
   serial_driver.table = serial_table;
   serial_driver.termios = serial_termios;
   serial_driver.termios_locked = serial_termios_locked;

   serial_driver.open = rs_open;
   serial_driver.close = rs_close;
   serial_driver.write = rs_write;
   serial_driver.put_char = rs_put_char;
   serial_driver.flush_chars = rs_flush_chars;
   serial_driver.write_room = rs_write_room;
   serial_driver.chars_in_buffer = rs_chars_in_buffer;
   serial_driver.flush_buffer = rs_flush_buffer;
   serial_driver.ioctl = rs_ioctl;
   serial_driver.throttle = rs_throttle;
   serial_driver.unthrottle = rs_unthrottle;
   serial_driver.send_xchar = rs_send_xchar;
   serial_driver.set_termios = rs_set_termios;
   serial_driver.stop = rs_stop;
   serial_driver.start = rs_start;
   serial_driver.hangup = rs_hangup;
   serial_driver.break_ctl = rs_break;
   serial_driver.wait_until_sent = rs_wait_until_sent;

   if (tty_register_driver(&serial_driver))
   {
      printk(KERN_ERR"ham:init: Could not register serial driver\n");
   }
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:init:serial driver registered\n");
   #endif
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:init:callout driver registered\n");
   #endif

   clm_configure();
   return (0);
}

/***************************************************************************
/ Function:  rs_open
/
/ Remarks:   This function is called when the line discipline is associated
/            with the tty.  The line discipline should initialize any
/            tracking variables here.
/
/ Inputs:    tty
/
/ Outputs:   status - operation status
****************************************************************************/
int rs_open(struct tty_struct *tty, struct file *file_ptr)
{
   struct async_struct *info;
   int    line;
   int    status;
   unsigned long page;
#if !defined(TARGET_SELAH)   
   long   retval;
#endif

   #if defined(DEBUG_LINUX)
   printk(KERN_INFO"ham:open: called by: %s [%d]\n", current->comm,
        current->pid);//tty->driver.name, MINOR(tty->device));
   #endif

#if defined (TARGET_CATAWBA)
   if (ModemCardStart == NULL) {
       printk(KERN_ERR"ham:rs_open: bad afe\n");      
       return (-ENODEV);
   }    
#endif

   if(MOD_IN_USE)
   {
      MOD_INC_USE_COUNT;
      #if defined(DEBUG_LINUX)
         printk(KERN_INFO"ham:rs_open: device already in use, count is now %d\n", MOD_IN_USE);
      #endif
      return(0);

   }
   MOD_INC_USE_COUNT;
   #if defined(DEBUG_LINUX)
      printk(KERN_DEBUG"ham:rs_open: count now = %d\n",MOD_IN_USE);
   #endif

   line = MINOR(tty->device) - tty->driver.minor_start;

   if ((line < 0) || (line >= CLM_PORTS))
   {
      MOD_DEC_USE_COUNT;
      printk(KERN_ERR"ham:rs_open: bad minor number %d, count now %d\n",line,MOD_IN_USE);
      return (-ENODEV);
   }

#if !defined(TARGET_SELAH)
   retval = ResetDspInternal();
   if(retval)
   {
      MOD_DEC_USE_COUNT;
      printk(KERN_ERR"ham:rs_open: DSP did not reset. try again or restart computer\n count now %d\n",MOD_IN_USE);
      return(-ENODEV);
   }
#endif
      info = &rs_async[line];
      info->magic = SERIAL_MAGIC;
      info->line = line;

      tty->driver_data = info;
      info->tty = tty;

      info->state = &serial_states[line];
      info->port =  info->state->port;
      info->flags = info->state->flags;
      info->xmit_fifo_size = info->state->xmit_fifo_size;
     

      info->tqueue.routine = rs_event_handler;
      info->tqueue.data = info;
      info->session = current->session;
      info->pgrp = current->pgrp;

      info->tty->low_latency = (info->flags & ASYNC_LOW_LATENCY) ? 1 : 0;

      info->state->normal_termios = serial_driver.init_termios;

      if (tty->driver.subtype == SERIAL_TYPE_NORMAL)
      {
         *tty->termios = info->state->normal_termios;
      }

      /* allocate temporary buffer to user/kernel mode transfers */
      page = get_free_page(GFP_KERNEL);
      tmp_buf = (unsigned char *)page;

      
      /* attach Interrupt Service Routine to DSP interrupt */
      dspdrv_clear_dsp_interrupt();
      dspdrv_SetCramISRCallBack(line_int);
      if(gSHIRQ == 1)
      {
         status = request_irq(ham_dsp_irq,
                              rs_interrupt,
                              SA_SHIRQ,
                              MDM_DEVICE_NAME, &gSHIRQ);
      }
      else
      {
         status = request_irq(ham_dsp_irq, 
                              rs_interrupt,
                              SA_INTERRUPT,
                              MDM_DEVICE_NAME, NULL);
      }
      #if defined(DEBUG_LINUX)
         printk(KERN_INFO"ham: request_irq: IRQ=%d shared=%d status=%d\n",
             ham_dsp_irq, gSHIRQ, status);
      #endif
      clm_initialize();
      #if defined(TARGET_CATAWBA)
        ModemCardStart();    
      #endif

      return (0);
}

/***************************************************************************
/ Function:  rs_close
/
/ Remarks:   This function is called when the line discipline is being
/            shutdown, either because the tty is being closed or because
/            the tty is being changed to use a new line discipline.
/
/ Inputs:    tty
/
/ Outputs:   none
****************************************************************************/
static void rs_close(struct tty_struct *tty, struct file *file_ptr)
{
   struct async_struct *info = (struct async_struct *)tty->driver_data;

   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:close: for: %s [%d]\n", current->comm,
        current->pid);//tty->driver.name, MINOR(tty->device));
   #endif

   if(MOD_IN_USE > 1)
   {
      MOD_DEC_USE_COUNT;
      #if defined(DEBUG_LINUX)
         printk(KERN_INFO"ham:rs_close: count now = %d\n",MOD_IN_USE);
      #endif
      return;
//      return(0);
   }
   else if(MOD_IN_USE == 0)
   {
      #if defined(DEBUG_LINUX)
         printk("ham:close: nothing to close\n");
      #endif
      return;
   }
   MOD_DEC_USE_COUNT; // if count is one
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:rs_close: count now = %d\n",MOD_IN_USE);
   #endif
   #if defined(TARGET_CATAWBA)
   ModemCardStop();    
   #endif
   clm_terminate();
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:close: clm_terminate done\n");
   #endif

   /* free hardware resources */
   free_irq(ham_dsp_irq, &gSHIRQ);
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:close:free_irq done\n");
   #endif
   if (tmp_buf != NULL)
   {
      free_page((unsigned long)tmp_buf);
      tmp_buf = NULL;
   }

   info->tty = 0;
   #if defined(DEBUG_LINUX)
      printk(KERN_INFO"ham:close:done\n");
   #endif
}

/***************************************************************************
/ Function:  rs_start
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static void rs_start(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;


   printk(KERN_ALERT"HAM: RS_START ****\n");

}

/***************************************************************************
/ Function:  rs_stop
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static void rs_stop(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;

   printk(KERN_ALERT"HAM:  RS_STOP ****\n");
}

/***************************************************************************
/ Function:  rs_put_char
/
/ Remarks:
/
/ Inputs:    tty
/            ch - transmit character
/
/ Outputs:   none
****************************************************************************/
static void rs_put_char(struct tty_struct *tty, unsigned char ch)
{
// struct async_struct *info = (struct async_struct *)tty->driver_data;

//   printk(KERN_DEBUG"ham:put_char: ch=%02x\n", ch);

   if (UART_dce_to_num() > 0)
   {
      UART_dce_to_char(ch);
   }
}

/***************************************************************************
/ Function:  rs_flush_chars
/
/ Remarks:   This function instructs the line discipline to completely
/            transmit all output characters it may have queued.
/
/ Inputs:    tty
/
/ Outputs:   none
****************************************************************************/
static void rs_flush_chars(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
   unsigned int  count;

   count = UART_dce_to_num();

//   printk(KERN_DEBUG"ham:flush_chars: count=%d\n", count);
}

/***************************************************************************
/ Function:  rs_write
/
/ Remarks:   This function is called when the user requests to write to the
/            tty.  The line discipline will deliver the characters to the
/            low-level tty device for transmission, optionally performing
/            some processing on the characters first.
/
/ Inputs:    tty - pointer to tty information
/            from_user - user to kernel space copy required indicator
/            buf - buffer contents to write
/            count - # bytes in buffer
/
/ Outputs:   actual - # bytes actually written
****************************************************************************/
static int rs_write(struct tty_struct *tty, int from_user, const unsigned
   char *buf, int count)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
   int   i;
   int   c;
   int   free;
   int   actual;

   #ifdef DBG_WRITE
   printk(KERN_INFO"ham:write: from=%d buf=%04x count=%d\n",
          from_user, (int)buf, count);
   printk(KERN_INFO"ham:rs_write: from %s [%d]\n",
          current->comm, current->pid);
   #endif

   actual = 0;

   /* if buffer is in user space, copy contents to kernel space first */
   if (from_user)
   {
      /* get exclusive access to tmp_buf */
      down(&tmp_buf_sem);

      /* move data until UART is full or write is completed */
      while (count > 0)
      {
         free = UART_dce_to_free();

         if (count > free)
            c = free;
         else
            c = count;

         if (c <= 0)
            break;

         /* copy data from user space to kernel space */
         c -= copy_from_user(tmp_buf, buf, c);
         if(!c) return (-EFAULT);
//         if (copy_from_user(tmp_buf, buf, c) != 0)
//            return (-EFAULT);

         for (i = 0; i < c; i++)
         {
            UART_dce_to_char(tmp_buf[i]);
         }

         buf += c;
         count -= c;
         actual += c;
      }

      /* release exclusive access to tmp_buf */
      up(&tmp_buf_sem);
   }
   else
   {
      /* move data until UART is full or write is completed */
      while (count > 0)
      {
         free = UART_dce_to_free();

         if (count > free)
            c = free;
         else
            c = count;

         if (c == 0)
            break;

         for (i = 0; i < c; i++)
         {
            UART_dce_to_char(buf[i]);
         }

         buf += c;
         count -= c;
         actual += c;
      }
   }

   return (actual);
}

/***************************************************************************
/ Function:  rs_write_room
/
/ Remarks:   This function is called by the low-level tty driver to
/            determine how many characters the line discipline can accept.
/
/ Inputs:    tty
/
/ Outputs:   count - # bytes available in write buffer
****************************************************************************/
static int rs_write_room(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
   int   count;
//   printk(KERN_DEBUG"ham:rs_write_room\n");
   count = UART_dce_to_free();
//   if (count == 0)
//      printk(KERN_INFO"ham:write_room: count=%d\n", count);
   return (count);
}

/***************************************************************************
/ Function:  rs_chars_in_buffer
/
/ Remarks:   This function returns the number of output characters that are
/            currently queued but not sent yet.
/
/ Inputs:    tty
/
/ Outputs:   count - # bytes queued in output buffer
****************************************************************************/
static int rs_chars_in_buffer(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
   unsigned int count;
//   printk(KERN_DEBUG"ham:rs_chars_in_buffer\n");

   count = UART_dce_to_num();

//   if (count > 0)
//      printk(KERN_INFO"ham:chars_in_buffer: count=%d\n", count);

   return (count);
}

/***************************************************************************
/ Function:  rs_flush_buffer
/
/ Remarks:   This routine instructs the line discipline to clear its
/            buffers of any output characters it may have queued to be
/            delivered but not yet sent.
/
/ Inputs:    tty
/
/ Outputs:   none
****************************************************************************/
static void rs_flush_buffer(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
   unsigned int count;
//   printk(KERN_DEBUG"ham:rs_flush_buffer\n");

   count = UART_dce_to_num();

//   if (count > 0)
//      printk(KERN_INFO"ham:flush_buffer: chars flushed=%d\n", count);

   UART_dce_flush();
}

/***************************************************************************
/ Function:  rs_wait_until_sent
/
/ Remarks:   Waits until transmitter is empty
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static void rs_wait_until_sent(struct tty_struct *tty, int timeout)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;

   ulong  orig_jiffies;

//   printk(KERN_DEBUG"ham:wait_until_sent: timeout=%d\n", timeout);

   if (UART_dce_to_num() == 0)
      return;

   orig_jiffies = jiffies;

   while (UART_dce_to_num() != 0)
   {
      current->state = TASK_INTERRUPTIBLE;

      //suse 8.0 decided to change this to dyn_prio?  2.4.18-4GB
      //but 2.4.18 still calles it counter.
      //I dont think we even need it.
      //current->counter = 0;  /* make us low-priority */

      schedule_timeout(1);

      if (signal_pending(current))
         break;

      if (timeout && time_after(jiffies, orig_jiffies + timeout))
         break;
   }

   current->state = TASK_RUNNING;
}

/***************************************************************************
/ Function:  rs_throttle
/
/ Remarks:   This routine is called by the upper-layer tty driver to signal
/            that incoming characters need to be throttled.
/
/ Inputs:    tty
/
/ Outputs:   none
****************************************************************************/
static void rs_throttle(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;

//   printk(KERN_DEBUG"ham:throttle:\n");


   if (I_IXOFF(tty))
   {
      rs_send_xchar(tty, STOP_CHAR(tty));
   }

   UART_rts_off();
}

/***************************************************************************
/ Function:  rs_unthrottle
/
/ Remarks:   This routine is called by the upper-layer tty driver to signal
/            that incoming characters no longer need to be throttled.
/
/ Inputs:    tty
/
/ Outputs:   none
****************************************************************************/
static void rs_unthrottle(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;


//   printk(KERN_DEBUG"ham:unthrottle:\n");


   if (I_IXOFF(tty))
   {
      rs_send_xchar(tty, START_CHAR(tty));
   }

   UART_rts_on();

   rs_send_xchar(tty, START_CHAR(tty));
}

/***************************************************************************
/ Function:  rs_send_xchar
/
/ Remarks:   This routine is used to send a high-priority XON/XOFF
/            character to the device.
/
/ Inputs:    tty
/
/ Outputs:   none
****************************************************************************/
static void rs_send_xchar(struct tty_struct *tty, char ch)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;

//   printk(KERN_DEBUG"ham:send_xchar: ch=%02x\n", ch);

   if (UART_dce_to_free() > 0)
   {
      UART_dce_to_char(ch);
   }
}


#define HIGH_BITS_OFFSET ((sizeof(long)-sizeof(int))*8)
static int get_serial_info(struct async_struct* info, struct serial_struct * retinfo)
{
	struct serial_struct tmp;
	struct serial_state *state = info->state;
   
	if (!retinfo)
		return -EFAULT;
	memset(&tmp, 0, sizeof(tmp));
	tmp.type = state->type;
	tmp.line = state->line;
	tmp.port = state->port;
	if (HIGH_BITS_OFFSET)
		tmp.port_high = state->port >> HIGH_BITS_OFFSET;
	else
		tmp.port_high = 0;
	tmp.irq = state->irq;
	tmp.flags = state->flags;
	tmp.xmit_fifo_size = state->xmit_fifo_size;
	tmp.baud_base = state->baud_base;
	tmp.close_delay = state->close_delay;
	tmp.closing_wait = state->closing_wait;
	tmp.custom_divisor = state->custom_divisor;
	tmp.hub6 = state->hub6;
	tmp.io_type = state->io_type;
	if (copy_to_user(retinfo,&tmp,sizeof(*retinfo)))
		return -EFAULT;
	return 0;

}

static int set_serial_info(struct async_struct* info, struct serial_struct * newinfo)
{
   return -EFAULT;
}

#if 0
	struct serial_struct new_serial;
 	struct serial_state old_state, *state;
	unsigned int		i,change_irq,change_port;
	int 			retval = 0;
	unsigned long		new_port;

	if (copy_from_user(&new_serial,new_info,sizeof(new_serial)))
		return -EFAULT;
	state = info->state;
	old_state = *state;

	new_port = new_serial.port;
	if (HIGH_BITS_OFFSET)
		new_port += (unsigned long) new_serial.port_high << HIGH_BITS_OFFSET;

	change_irq = new_serial.irq != state->irq;
	change_port = (new_port != ((int) state->port)) ||
		(new_serial.hub6 != state->hub6);
  
	if (!capable(CAP_SYS_ADMIN)) {
		if (change_irq || change_port ||
		    (new_serial.baud_base != state->baud_base) ||
		    (new_serial.type != state->type) ||
		    (new_serial.close_delay != state->close_delay) ||
		    (new_serial.xmit_fifo_size != state->xmit_fifo_size) ||
		    ((new_serial.flags & ~ASYNC_USR_MASK) !=
		     (state->flags & ~ASYNC_USR_MASK)))
			return -EPERM;
		state->flags = ((state->flags & ~ASYNC_USR_MASK) |
			       (new_serial.flags & ASYNC_USR_MASK));
		info->flags = ((info->flags & ~ASYNC_USR_MASK) |
			       (new_serial.flags & ASYNC_USR_MASK));
		state->custom_divisor = new_serial.custom_divisor;
		goto check_and_exit;
	}

	new_serial.irq = irq_cannonicalize(new_serial.irq);

	if ((new_serial.irq >= NR_IRQS) || (new_serial.irq < 0) || 
	    (new_serial.baud_base < 9600)|| (new_serial.type < PORT_UNKNOWN) ||
	    (new_serial.type > PORT_MAX) || (new_serial.type == PORT_CIRRUS) ||
	    (new_serial.type == PORT_STARTECH)) {
		return -EINVAL;
	}

	if ((new_serial.type != state->type) ||
	    (new_serial.xmit_fifo_size <= 0))
		new_serial.xmit_fifo_size =
			uart_config[new_serial.type].dfl_xmit_fifo_size;

	/* Make sure address is not already in use */
	if (new_serial.type) {
		for (i = 0 ; i < NR_PORTS; i++)
			if ((state != &rs_table[i]) &&
			    (rs_table[i].port == new_port) &&
			    rs_table[i].type)
				return -EADDRINUSE;
	}

	if ((change_port || change_irq) && (state->count > 1))
		return -EBUSY;

	/*
	 * OK, past this point, all the error checking has been done.
	 * At this point, we start making changes.....
	 */

	state->baud_base = new_serial.baud_base;
	state->flags = ((state->flags & ~ASYNC_FLAGS) |
			(new_serial.flags & ASYNC_FLAGS));
	info->flags = ((state->flags & ~ASYNC_INTERNAL_FLAGS) |
		       (info->flags & ASYNC_INTERNAL_FLAGS));
	state->custom_divisor = new_serial.custom_divisor;
	state->close_delay = new_serial.close_delay * HZ/100;
	state->closing_wait = new_serial.closing_wait * HZ/100;
#if (LINUX_VERSION_CODE > 0x20100)
	info->tty->low_latency = (info->flags & ASYNC_LOW_LATENCY) ? 1 : 0;
#endif
	info->xmit_fifo_size = state->xmit_fifo_size =
		new_serial.xmit_fifo_size;

	if ((state->type != PORT_UNKNOWN) && state->port) {
#ifdef CONFIG_SERIAL_RSA
		if (old_state.type == PORT_RSA)
			release_region(state->port + UART_RSA_BASE, 16);
		else
#endif
		release_region(state->port,8);
	}
	state->type = new_serial.type;
	if (change_port || change_irq) {
		/*
		 * We need to shutdown the serial port at the old
		 * port/irq combination.
		 */
		shutdown(info);
		state->irq = new_serial.irq;
		info->port = state->port = new_port;
		info->hub6 = state->hub6 = new_serial.hub6;
		if (info->hub6)
			info->io_type = state->io_type = SERIAL_IO_HUB6;
		else if (info->io_type == SERIAL_IO_HUB6)
			info->io_type = state->io_type = SERIAL_IO_PORT;
	}
	if ((state->type != PORT_UNKNOWN) && state->port) {
#ifdef CONFIG_SERIAL_RSA
		if (state->type == PORT_RSA)
			request_region(state->port + UART_RSA_BASE,
				       16, "serial_rsa(set)");
		else
#endif
			request_region(state->port,8,"serial(set)");
	}

	
check_and_exit:
	if (!state->port || !state->type)
		return 0;
	if (info->flags & ASYNC_INITIALIZED) {
		if (((old_state.flags & ASYNC_SPD_MASK) !=
		     (state->flags & ASYNC_SPD_MASK)) ||
		    (old_state.custom_divisor != state->custom_divisor)) {
#if (LINUX_VERSION_CODE >= 131394) /* Linux 2.1.66 */
			if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_HI)
				info->tty->alt_speed = 57600;
			if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_VHI)
				info->tty->alt_speed = 115200;
			if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_SHI)
				info->tty->alt_speed = 230400;
			if ((state->flags & ASYNC_SPD_MASK) == ASYNC_SPD_WARP)
				info->tty->alt_speed = 460800;
#endif
			change_speed(info, 0);
		}
	} else
		retval = startup(info);
	return retval;

}
#endif //0

/***************************************************************************
/ Function:  rs_ioctl
/
/ Remarks:   This function is called when the user requests an ioctl which
/            is not handled by the tty layer or the low-level tty driver.
/            It is intended for ioctls which affect line discipline
/            operation.
/
/ Inputs:    tty
/            file_ptr
/            cmd
/            arg
/
/ Outputs:   status - operation status
****************************************************************************/
static int rs_ioctl(struct tty_struct *tty, struct file *file_ptr,
   unsigned int cmd, unsigned long arg)
{
   ubyte ring, nring;
   ubyte dsr, ndsr;
   ubyte dcd, ndcd;
   ubyte cts, ncts;
	struct async_struct * info = (struct async_struct *)tty->driver_data;
/*****************
     printk(KERN_DEBUG
     "ham:ioctl[%X]: dir[%d], type[%d], nr[%d], size[%d]\n",
             cmd,
             _IOC_DIR(cmd),
             _IOC_TYPE(cmd),
             _IOC_NR(cmd),
             _IOC_SIZE(cmd));
********************/
   switch (cmd)
   {
//===============================================================
//CASES that may need implementing
    case TIOCSERCONFIG:
        return (0); //should return do_autoconfig?
    case TIOCSERGETLSR:
        return (0); //gosh we dont return LSR?  oh boy
        //we should return get_lsr_info(info,(struct serial_struct* arg));
   case TIOCSERGSTRUCT:
        //return is ok but should copy async struct to user
        //copy_to_user((struct async_struct *) arg, 
        //              info, sizeof(struct async_struct)))
      return (0);
  //TIOCMIWAIT needs verified for correctness. see implementation 
   case TIOCGICOUNT:
        //UGH! this needs implementing, i wonder what this breaks
        // Get counter of input serial line interrupts (DCD,RI,DSR,CTS)
        // Return: write counters to the user passed counter struct
        // NB: both 1->0 and 0->1 transitions are counted except 
        // for RI where only 0->1 is counted.

        //save flags clear ints
        //store count now
        //restore flags
        //set icount args with cnow
        //cts,dsr,rng,dcd,rx,tx,frame,overrun,parity,brk,buf_overrun
       //and copy the icount struct to the user
        return (0);

//===============================================================
//CASES NOT IN SERIAL.C BUT TTY
    case TCGETS: // tty calls get_termios
    case TCSETS: // tty calls set_termios
    case TCFLSH: // tty calls flush_buffer for various cases
    case TCSETSF: //tty calls set_termios TERMIOS_FLUSH
        return (-ENOIOCTLCMD);

//===============================================================
//CASES FOR ONLY 2.1 KERNEL, IGNORE, RETURN AS DEFALUT
    case TCSBRK:
    case TCSBRKP:
    case TIOCGSOFTCAR:
    case TIOCSSOFTCAR:
        return (-ENOIOCTLCMD);

//===============================================================
//OLD rejected DEBIAN call setserial -W
    case TIOCSERGWILD:
    case TIOCSERSWILD:
      // "setserial -W" is called in Debian boot
      printk ("TIOCSER?WILD ioctl obsolete, ignored.\n");
      return (0);
//===============================================================
//CASES FOR MULTIPORT THAT DONT APPLY TO US
                                 
    case TIOCSERGETMULTI:
    case TIOCSERSETMULTI:
        return (-ENOIOCTLCMD);


//===============================================================
//CASES implemented as serial.c does
   case TIOCMGET:
//      printk(KERN_DEBUG"ham:ioctl (TIOCMGET)\n");
      return (get_modem_info(tty, (unsigned int *) arg));

   case TIOCMBIS:
   case TIOCMBIC:
   case TIOCMSET:
//      printk(KERN_DEBUG"ham:ioctl (TCCMBIS,TIOCMBIC,TIOCMSET)\n");
      return (set_modem_info(tty, cmd, (unsigned int *)arg));

   case TIOCGSERIAL:
      return get_serial_info(info,(struct serial_struct *) arg);

   case TIOCSSERIAL:
      return set_serial_info(info,(struct serial_struct *) arg);

   case TIOCMIWAIT:
       //save flags and clear ints
       //save counters on entry
       //restore flags
       //turn modem ints on (IER |= UART_IER_MSI)
       //while 1
       //interruptible sleep on a change in MSR
       //see if a signal did it with signal_pending(current)
       //save flags and clear ints
       //store int count (atomic copy?)
       //restore flags
       //if not change to the four ints return error
       //return 0 when an int specified in the arg mask has changed
       //if no change store the current count to previous count

      ring = UART_line_status(RINGING);
      dsr = UART_line_status(DSR);
      dcd = UART_line_status(RLSD);
      cts = UART_line_status(CTS);
  
//      printk(KERN_DEBUG"\tpre: rng,dsr,dcd,cts %1d%1d%1d%1d\n", ring, dsr, dcd, cts);
  

      while (1)
      {
         /* wait until line status changes */
         UART_msr_wait();

         /* if no signal pending, exit */
         if (signal_pending(current))
            return (-ERESTARTSYS);

         nring = UART_line_status(RINGING);
         ndsr = UART_line_status(DSR);
         ndcd = UART_line_status(RLSD);
         ncts = UART_line_status(CTS);

//       printk(KERN_DEBUG"post: rng,dsr,dcd,cts %1d%1d%1d%1d\n",nring, ndsr,ndcd,ncts);


         /* if no signals changed, return error */
         if ((nring == ring) && (ndsr == dsr) && (ndcd == dcd) && (ncts == cts))
         {
            return (-EIO);
         }

         if (((arg & TIOCM_RNG) && (nring != ring)) ||
             ((arg & TIOCM_DSR) && (ndsr != dsr))   ||
             ((arg & TIOCM_CD)  && (ndcd != dcd))   ||
             ((arg & TIOCM_CTS) && (ncts != cts)))
         {
            return (0);
         }
      }
      break;

   default:
     if(_IOC_TYPE(cmd) == 't')
     {
//        printk(KERN_DEBUG"ham:ioctl:ppp -ENOIOCTLCMD\n");
        return(-ENOIOCTLCMD);
     }
/*
     printk(KERN_WARNING
     "ham:ioctl:unknown[%X], dir[%d], type[%d], nr[%d], size[%d]\n",
             cmd, 
             _IOC_DIR(cmd),
             _IOC_TYPE(cmd),
             _IOC_NR(cmd),
             _IOC_SIZE(cmd));
*/
      return (-ENOIOCTLCMD);

   }

   return (0);
}


/***************************************************************************
/ Function:  rs_set_termios
/
/ Remarks:   This function notifies the line discipline that a change has
/            been made to the termios structure.
/
/ Inputs:    tty
/            old_termios
/
/ Outputs:   none
****************************************************************************/
static void rs_set_termios(struct tty_struct *tty, struct termios
   *old_termios)
{
   struct async_struct *info = (struct async_struct *)tty->driver_data;
   unsigned int cflag;
   unsigned int iflag;

//   printk(KERN_DEBUG"ham:set_termios: cf=%x / %x if=%x / %x\n",
//   tty->termios->c_cflag, old_termios->c_cflag, 
//   tty->termios->c_iflag, old_termios->c_iflag);

   cflag = tty->termios->c_cflag;

   if (cflag & ASYNC_HARDPPS_CD)
   {
//      printk(KERN_INFO"ham: ASYNC_HARDPPS_CD set\n");
   }

   if (cflag & CRTSCTS)
   {
//      printk(KERN_INFO"ham: Hardware flow control enabled\n");
      info->flags |= ASYNC_CTS_FLOW;
   }
   else
   {
 //     printk(KERN_INFO"ham: Hardware flow control disabled\n");
      info->flags &= ~ASYNC_CTS_FLOW;
   }

   if (cflag & CLOCAL)
   {
//      printk(KERN_INFO"ham: CLOCAL set\n");
      info->flags &= ~ASYNC_CHECK_CD;
   }
   else
   {
//      printk(KERN_INFO"ham: CLOCAL cleared\n");
      info->flags |= ASYNC_CHECK_CD;
   }

   iflag = tty->termios->c_iflag;
   
   if (iflag & IXOFF)
   {
 //     printk(KERN_INFO"ham: Software flow control on input enabled\n");
   }
   else
   {
//      printk(KERN_INFO"ham: Software flow control on input disabled\n");
   }      

   if (iflag & IXON)
   {
//      printk(KERN_INFO"ham: Software flow control on output enabled\n");
   }
   else
   {
//      printk(KERN_INFO"ham: Software flow control on output disabled\n");
   }
}

/***************************************************************************
/ Function:  rs_hangup
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static void rs_hangup(struct tty_struct *tty)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
#if defined(DEBUG_LINUX)
   printk(KERN_DEBUG"ham:hangup:\n");
#endif

   rs_flush_buffer(tty);
   // issue an ath and atz or some function to reset and hangup the modem

    //   if (info->flags & ASYNC_CLOSING)
    //        return;
    //shutdown(info);
    //info->event = 0;
    //state->count = 0;
    //info->flags &= ~(ASYNC_NORMAL_ACTIVE|ASYNC_CALLOUT_ACTIVE);
    //info->tty = 0;
    //wake_up_interruptible(&info->open_wait);

}

/***************************************************************************
/ Function:  rs_break
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static void rs_break(struct tty_struct *tty, int break_state)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;

#if defined(DEBUG_LINUX)
   printk(KERN_DEBUG"ham:break:\n");
#endif

}

/***************************************************************************
/ Function:  get_modem_info
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static int get_modem_info(struct tty_struct *tty, unsigned int *value)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
   unsigned int status;
//      printk(KERN_DEBUG"ham:get_modem_info\n");

   status = 0;
   if(!MOD_IN_USE)
   {
//      printk(KERN_EMERG"HAM: GET_MODEM_INFO: module not in use! mod count %d\n",MOD_IN_USE);
      return -ENODEV;
   }
   if (UART_line_status(RTS))
      status |= TIOCM_RTS;
   if (UART_line_status(DTR))
      status |= TIOCM_DTR;
   if (UART_line_status(RINGING))
      status |= TIOCM_RNG;
   if (UART_line_status(DSR))
      status |= TIOCM_DSR;
   if (UART_line_status(CTS))
      status |= TIOCM_CTS;
   if (UART_line_status(RLSD))
      status |= TIOCM_CAR;

//   printk(KERN_INFO"ham: get_modem_info: status=%04x\n", status);

   return (put_user(status, value));
}

/***************************************************************************
/ Function:  set_modem_info
/
/ Remarks:
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static int set_modem_info(struct tty_struct *tty, unsigned int cmd,
   unsigned int *value)
{
//   struct async_struct *info = (struct async_struct *)tty->driver_data;
   int error;
   unsigned int arg;
//      printk(KERN_DEBUG"ham:get_modem_info\n");
   if(!MOD_IN_USE)
   {
//      printk(KERN_EMERG"HAM: SET_MODEM_INFO: mod not in use! mod count %d\n",MOD_IN_USE);
      return -ENODEV;
   }
   error = get_user(arg, value);
   if (error)
   {
      printk(KERN_ERR"ham: set_modem_info: returning error %d\n", error);
      return (error);
   }

   switch (cmd)
   {
   case TIOCMBIS:
//      printk(KERN_INFO"ham: set_modem_info (TIOCMBIS) arg=%d\n", arg);

      if (arg & TIOCM_RTS)
         UART_rts_on();
      if (arg & TIOCM_DTR)
         UART_dtr_on();
//    if TIOCM_OUT1 is defined
//    if (arg & TIOCM_OUT1)
//    if (arg & TIOCM_OUT2)
//    else if TIOCM_LOOP Enable loopback test mode
      break;

   case TIOCMBIC:
//      printk(KERN_INFO"ham: set_modem_info (TIOCMBIC) arg=%d\n", arg);

      if (arg & TIOCM_RTS)
         UART_rts_off();
      if (arg & TIOCM_DTR)
         UART_dtr_off();
//    if TIOCM_OUT1 is defined
//    if (arg & TIOCM_OUT1)
//    if (arg & TIOCM_OUT2)
//    else if TIOCM_LOOP Enable loopback test mode

      break;

   case TIOCMSET:
//      printk(KERN_INFO"ham: set_modem_info (TIOCMSET) arg=%d\n", arg);
      //turn rts, out1, out2, loop, dtr off
      //then turn the ones set true to on

      if (arg & TIOCM_RTS)
         UART_rts_on();
      else
         UART_rts_off();

      if (arg & TIOCM_DTR)
         UART_dtr_on();
      else
         UART_dtr_off();

      break;

   default:
      printk(KERN_ERR"ham: set_modem_info: unknown cmd=%d\n", cmd);
      return -EINVAL;
   }

  return 0;
}

/***************************************************************************
/ Function:  rs_interrupt
/
/ Remarks:   Interrupt service routine
/
/ Inputs:
/
/ Outputs:
****************************************************************************/
static void rs_interrupt(int irq, void *dev_id, struct pt_regs *regs)
{
   struct async_struct *info = &rs_async[0];
   ubyte  intr_status;
//   printk(KERN_DEBUG"ham:interrupt: irq=%d\n",irq);

   if (!info || !info->tty)
   {
      printk(KERN_DEBUG"ham:interrupt: no info\n");
      return;
   }
#if defined (TARGET_CATAWBA)
   AfeIRQ();
#elif defined(TARGET_SELAH)
   intr_status = IM_Peek_Reg(CMHISR);
   if ((intr_status & bHIS_MP) == 0)
   {
	   //not our interrupt
      return;
   }
#else
   intr_status = get_register(INTEV_REG);
   //printk(KERN_DEBUG"ham: intr_status=%d\n",intr_status);
   if ( !(intr_status & CPINT_STAT))
   {
      return;
   }
#endif 
   dspdrv_CommRamISR();
}

/***************************************************************************
/ Function:  rs_receive
/
/ Remarks:   This function is used to receive incoming characters into the
/            host interface buffer.
/
/ Inputs:    none
/
/ Outputs:   none
****************************************************************************/
void rs_receive(void)
{
   unsigned char ch;
   unsigned long flags;

   struct async_struct *info = &rs_async[0];
   struct tty_struct *tty = info->tty;

//   #ifdef DBG_RECIEVE
//   printk(KERN_DEBUG"ham:recieve: from %s [%d]\n",current->comm, current->pid);
//   #endif
   while ((UART_dte_to_num() > 0) && (tty->flip.count < TTY_FLIPBUF_SIZE))
   {
      ch = UART_dte_from_char();
      save_flags(flags);
      cli();

      *tty->flip.char_buf_ptr = ch;
      *tty->flip.flag_buf_ptr = 0;

      tty->flip.flag_buf_ptr++;
      tty->flip.char_buf_ptr++;
      tty->flip.count++;
      tty_flip_buffer_push(tty);

      restore_flags(flags);
   }
}

/***************************************************************************
/ Function:  rs_sched_event
/
/ Remarks:   This function is used to schedule a background event handler
/            to run.
/
/ Inputs:    none
/
/ Outputs:   none
****************************************************************************/
void rs_sched_event(void)
{
   struct async_struct *info = &rs_async[0];

   info->event |= 1 << RS_EVENT_WRITE_WAKEUP;

//   printk(KERN_DEBUG"ham:sched_event: queuing task\n");
   queue_task(&info->tqueue, &tq_immediate);

//   printk(KERN_DEBUG"ham:sched_event: marking bh to run\n");
   mark_bh(IMMEDIATE_BH);
}

/***************************************************************************
/ Function:  rs_event_handler
/
/ Remarks:   This function is the background event handler.
/
/ Inputs:    none
/
/ Outputs:   none
****************************************************************************/
static void rs_event_handler(void *ptr)
{
   struct async_struct *info = (struct async_struct *)ptr;
   struct tty_struct *tty;
   
   if ((tty = info->tty) == NULL)
      return;
      
   if (test_and_clear_bit(RS_EVENT_WRITE_WAKEUP, &info->event))
   {
      if ((tty->flags & (1 << TTY_DO_WRITE_WAKEUP)) &&
          (tty->ldisc.write_wakeup != NULL))
      {
//         printk(KERN_DEBUG"ham:event_handler: ldisc wakeup\n");
         (tty->ldisc.write_wakeup)(tty);
      }

//      printk(KERN_DEBUG"ham:event_handler: waking up write_wake\n");
      wake_up_interruptible(&tty->write_wait);
   }
}
