ReadMe file for the
Intel� MD563X-HaM V.92 chipset Linux driver

contents:
1.  License
2.  Release Notes
3.  Installation
4.  File Descriptions
5.  International Users
6.  Beta Tester appreciation
7.  Security issues
8.  Compilation issues
    a. Instructions for Debian Users
    b. Kernel Source
9.  What is the Hamregistry?
10. what's v92 and v44?
11. The Hamregistry tool (for persistance)
12. Known Bugs/Issues
13. Comments, ideas, problems, fixes

-------------------------------------------------------------------------------
1. LICENSE

IMPORTANT - read the file "LICENSE.txt" for the INTEL SOFTWARE LICENSE 
AGREEMENT BEFORE COPYING, INSTALLING OR USING.


also note:
The serial driver open source code located in the directory "serialdrv" 
is work covered under the GNU GENERAL PUBLIC LICENSE (GPL).
The "serialdrv" directory has the GPL in the file "GPL.txt".

-------------------------------------------------------------------------------
2. Release Notes 

      This release supports 2.4.x kernels.

      This release is not compatible to 2.2.x kernels, please use 
      the 333-5 Linux HaM driver.

      The HaM corecode binary was compiled with gcc version 3.2

      v92 support added:  modem on hold AT command set,
      PCM upstream, v44, and quick connect are implemented.			 

      Linux Compatability tests are performed on the latest or previous 
      versions of the following distributions: Mandrake, RedHat, and SuSE

-------------------------------------------------------------------------------
3.  INSTALLATION

Prerequisites:
   1. root access
   2. bash shell to run install scripts
   3. a HaM modem
   4. KERNEL SOURCE HEADERS FOR THE KERNEL YOU ARE RUNNING
      (found on your distribution's CD)

6 steps to install
   1. login as ROOT 
   2. extract the archive into a directory with "tar -zxvf <archivename>.tgz"
   3. cd into the directory it created.
   4. Type: make clean
   5. Type: make ham
   6. Type: make install



The installation script has been designed for the following distributions 
release versions

   mandrake-release
   SuSE-release
   redhat-release
   debian_version (including Corel)
   slackware-version
   conectiva-version
   bluepoint-release
   Unknown distributions install modules and utilities but
   will not install boot scripts!.

Please examine the haminst script if you have a different distribution.

The driver is split in two.  A ham serial driver and core driver.
The core driver must be loaded first since the serial driver depends on it.
The serial driver registers itself as character device 
   major number 240, minor number 1.
The serial driver takes one argument right now, which is a number to 
   override the default major number if you need to.


ATTENTION:  if the driver compiles but the script just wont work for you.
   Here are the bare minimum steps to get your modem to work.

   0.  log in as root.
   1.  insmod -f hamcore.o
   2.  insmod -f ham.o
   2a. you can start "hamregistry" at this point if you wish.
   3.  rm /dev/ham
   4.  mknod /dev/ham c 240 1   (note "240" is the default, if it does not 
       work see what /proc/devices says ham's major number is)
   5.  ln -s /dev/ham /dev/modem
   6.  start a comm application like minicom and use the modem.
   7.  see section 3 (International Users) for info on setting the correct 
       country settings.


-------------------------------------------------------------------------------
4.  FILE DESCRIPTIONS

haminst installation script to install HaM modules and supporting files


files copied to /lib/modules/(kernel-version)/misc
   hamcore.o	driver core code module
   ham.o		pseudo serial driver for HaM, depends on hamcore.o

files copied to  /etc/rc.d/...  (path differes per distribution)
   hamboot		boot scrip to start and stop HaM modules

files copied to /usr/sbin
   hamregistry	hamregistry is the "registry" like tool that the modem uses to 
   get and store persistant data such as county info and profile strings.

files copied to /etc
   hamregistry.bin	file that stores the initial persistant data for modem.


-------------------------------------------------------------------------------
5.  INTERNATIONAL USERS

hamregistry will store the last country setting you
set in the modem.

in minicom (or equivalent comm application)
the commmand to change country setting is "AT+GCI="
the command takes a t.35 country code in hexadecimal.
below is a list of currently supported t.35 country codes.
you can also put this "AT" command in the init string of
the comm application you are using.

if you are a CTR-21 country I think you should be able to 
choose a CTR-21 country on the list and be ok.  but 
that's no guarantee.
The same goes for countries that are "USA" compatable.
(this table also exist in the source file wwh_dflt.c that
ships with the hamcore driver)

country  code   t.35 code
---------------------------
USA      1      B5 
KOR      82     61 
ECU      593    35 
BOL      591    14 
CHL      56     15 
COL      57     27 
PAN      507    85 
PER      51     88 
SAU      966    98 
THA      66     A9 
VNM      84     BC 
SWE      46     A5 
DNK      45     31 
FIN      358    3C 
NOR      47     82 
ISL      354    52 
IRL      353    57 
ISR      972    58 
LIE      423    68 
ESP      34     A0
TUR      90     AE
DEU      49     42
AUT      43     0A
CHE      41     A6
CYP      357    2D
GRC      30     46
ITA      39     59
LUX      352    69
NLD      31     7B 
GBR      44     B4 
BEL      32     0F
FRA      33     3D
PRT      351    8B
PAK      92     84
JPN      81     00
RUS      7      B8
AUS      61     09
MYS      60     6C
CHN      86     26
HKG      852    50
SGP      65     9C
NZL      64     7E
ARG      54     07
BRA      55     16
MEX      52     73
TWN      886    E3
IND      91     53
PHL      63     89
IDN      62     54
BHS      103    0B 
BRB      104    0E 
BMU      105    12 
GTM      502    49 
HTI      509    4E 
HND      504    4F 
JAM      1      5B 
NIC      505    7F 
PRY      595    87 
PRI      121    8C 
SUR      597    A3 
TTO      117    AC 
URY      598    B7 
VEN      58     BB 
ZWE      263    C4
GUY      592    4D
EST      372    E0
HUN      36     51
SVN      386    E2
ARE      971    B3 
SVK      421    2E
CAN      107    14 
CRI      506    1B 
DOM      110    33 
SLV      503    37 
GMB      220    41 
GIB      350    45 
POL      48     8A
EGY      20     36
CZE      420    2E
ZAF      27     9F
GUF      594    E1


-------------------------------------------------------------------------------
6.  Thanks to the following beta testers for their valuable input and 
    suggestions during the HaM 333 beta test between January 2 - 26, 2001

Dorian S. Araneda
Sean Walbran
Rob Clark
Marvin Stodolsky
Dominique Duval
Roman Krais 
Ulrich Guenther
Marcelino Viana Pinheiro
Thomas S. Iversen
Jospeh Teichman
Michel Bartolone (MED)
Ramon Gonzalez Montoiro
Ryoji Kawagishi
Torsten Vogel
"jandro"
Ian Carr-de Avelon
Helga Weindl
Ed Casas
Bernhard Hoelcker
Alexander "Sasha" Voytov
Albert Woo
Peter Hirschmann

and all of the helpful Linux HaM users
around the world and at www.linmodems.org 

-------------------------------------------------------------------------------
7. Security issues

the haminst and hamboot file install the files and device nodes as 
root for the owner and group.  
this will cause problems for those who want to user the modem to dialout
using an account other than root.

In SuSE, "dialout" is the group used to install the files and device node.
This way, anyone belonging to the "dialout" group can use the modem to dialout.
(take a look at /etc/group)

I did not want the script to allow full access of the modem to everyone without
"root" knowing.

Edit the hamboot and haminst scripts to fit your needs.

-------------------------------------------------------------------------------
8. Compile issues
   a. this driver will now compile with the this path:
   /lib/modules/<kernel version>/build/include
   the 2.4.4+ kernels says to copy the /boot/vmlinuz.version.h
   over to the kernel build path.  I have the makefile do this
   if this file exists.  You must install the kernel source
   code anyways.  It should be on your distribution's CD.


-------------------------------------------------------------------------------
9.  What is the Hamregistry?
   The hamregistery is an application that stores data for the ham driver onto
   the disk.  hamregistry stores information from the driver that needs to 
   persist from reboot to reboot such as you current country setting.
      The haminst install script and the hamboot script start this utility 
      automatically for you.
   If this tool is not present when the driver gets used your profile, 
   quickconnect, and current country setting will not be saved but the driver
   should still work fine.	The only step that would need to be done is to
   make sure that the driver is set to the correct country with 
   at+gci= (see section 5)


-------------------------------------------------------------------------------
10. What's v92 and v44?  

   a. modem on hold: (ISP and your ISP dialer must also support this)
      This will allow you to pause your ppp connection to answer an incoming
      call. You will need call waiting, dialer, and ISP support for this to 
      work.  When you are done with the call you can resume your ppp connection
      without having to reconnect.  The AT command set for this feature exist
      in the driver.

   b, pcm upstream: 
      (ISP must also support this, as of version 4.32 I
       dont know any ISP's that do)
      This will allow faster upload speeds.
      to enable: at+pig=0
      to disable: at+pig=1

   c. quickconnect:
      Once you make a call to a v92 modem, your phoneline characteristics are
      stored.  Whenever you make a new v92 connection it will use this data 
      to make the call negotiation  quicker (approx 10 seconds).
      to enable: at+pqc=0  at+pss=0
      to disable: at+pss=2

   d. v44: (ISP must also support this)
      A better compression protocol than v42 which can give you better transfer
      speeds.

-------------------------------------------------------------------------------
11. The Hamregistry tool
   
   The hamregistry tool is used to provide persistance of settings across
   reboots.  The haminst and hamboot scripts automatically setup and start
   the hamregistry background task for the modem to use.
   The hamregistry tool has command line arguments for those who wish to 
   customize persistant settings.  To use these command lines
   you must first stop the driver with "bash hamboot stop".
   Once the driver has been stopped you may run hamregistry with one of these
   arguments to store into the /etc/hamregistry.bin persistance file:
   (supply value for items in < >)
      -mfg <Modem manufactures name>
      -mod <Modem model name>
      -hookflash  <0,1,2>
        hookflash method:  0=(default)without tone  1=with tone  2=reserved
      -v92rptopt  <0,1>
        control v92 reporting:   0=PCM upsteam only       1=(default) all v92
      -gpio_lpohd <0,1>
        Handset Hook detection:  0=not supported          1=(default)supported
      -currentcountry <t.35 code>

   This info is written to the /etc/hamregistry.bin file.
   If hamregistry.bin exists along with the installation files, haminst will
   copy it to /etc/hamregistry.bin when installing the modem.

-------------------------------------------------------------------------------
12. Known Bugs/Issues

   a. If you see this message 
      "ham:rs_open: DSP did not reset. try again or restart computer"
      and you KNOW you have a HaM modem installed
      Disable "PNP OS" in your bios.  There is a problem with the driver and 
      linux PNP.  After a time, Linux PNP will disable the card and the driver
      currently can not reenable itself.
   b. Be aware that the build replaces your 
      /lib/module/<kernver>//build/include/linux/version.h file with 
      /boot/vmlinuz.version.h
      (this is what Linus T. told me to do with a compiler error)
   c. There may be an incompatibility with DevFS. The ham device may be located
      in /dev/tts/ham
      instead of /dev/ham.  Be aware of this and link /dev/modem to the ham 
      device that corresponds to your setup.
   d. SuSE 7.3 has our 412-3  HaM driver on the CD set.
      To install it the command is:
      rpm -Uhv /cdrom/suse/pay1/Intel-v92ham.rpm
   f. There is a compile problem with HaM version 4.25 and SuSe 7.2
      remove our comment the line "#define EXPORT_SYMTAB"  for it to compile.
   e. Incase you are having problems making a ppp connection try using wvidal
      with this information below. execute the script and it will have wvdial
      make the ppp connection

   ------my script----------------------
   #! /bin/sh
   /usr/sbin/pppd -detach lock asyncmap 00000000 \
      defaultroute debug /dev/modem 57600 \
      ipparam ppp0 linkname ppp0 \
      noauth \
      connect "/usr/bin/wvdial --chat bellsouth"

   ------my /etc/wvdial.conf section ---
   [Dialer bellsouth]
   Modem = /dev/modem
   Baud = 57600
   Init1 = ATZ
   Inti2 = ATQ0 V1 E1 S0=0 &C1 &D2
   Dial Command = ATDT
   Phone = 6859500
   Username = myloginname
   Password = mysecretpassword
   #Ask Password = 1
   Stupid Mode = 0
   ------------------


-------------------------------------------------------------------------------
13. Comments, ideas, problems, fixes? please contact:

Linux Voice Band Modems (VBM) of Intel Residential Access Division (RAD)

vbm.linux@intel.com
http://developer.intel.com/design/modems/

To restrict email volume, please email only development related issues that are
needed to fix a bug or improve the driver. General questions on how to use the 
Linux OS will have to be forwarded.

Other resources and information on Linux controllerless modems can be found on 
these usefull sites

http://www.linmodems.org 
	and
http://linmodems.technion.ac.il


